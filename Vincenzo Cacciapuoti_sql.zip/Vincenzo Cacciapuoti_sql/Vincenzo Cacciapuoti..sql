-- DATABASE
DROP DATABASE IF EXISTS ToysGroup;
CREATE DATABASE ToysGroup;
USE ToysGroup;

-- CATEGORIA
CREATE TABLE Categoria (
  Id_Categoria INT PRIMARY KEY,
  Nome_Categoria VARCHAR(25)
);

INSERT INTO Categoria VALUES
(1, 'Videogame'),
(2, 'Biciclette'),
(3, 'Giochi da tavolo'),
(4, 'Bambole');

-- PRODOTTO
CREATE TABLE Prodotto (
  Id_Prodotto INT PRIMARY KEY,
  Id_Categoria INT,
  Nome_Prodotto VARCHAR(25),
  FOREIGN KEY (Id_Categoria) REFERENCES Categoria(Id_Categoria)
);

INSERT INTO Prodotto VALUES
(1, 1, 'Fifa 25'),
(2, 2, 'E-ST500'),
(3, 3, 'Monopoli'),
(4, 4, 'Barbie'),
(5, 2, 'MTB 900'),
(6, 1, 'Call of Honor'),
(7, 3, 'Uno Flip');

-- REGIONE
CREATE TABLE Regione (
  Id_Regione INT PRIMARY KEY,
  Nome_Regione VARCHAR(25)
);

INSERT INTO Regione VALUES
(1, 'SouthEurope'),
(2, 'NorthEurope'),
(3, 'EasternEurope');

-- STATO
CREATE TABLE Stato (
  Id_Stato INT PRIMARY KEY,
  Nome_Stato VARCHAR(25),
  Id_Regione INT,
  FOREIGN KEY (Id_Regione) REFERENCES Regione(Id_Regione)
);

INSERT INTO Stato VALUES
(1, 'Ialia', 1),
(2, 'Spagna', 1),
(3, 'Germania', 2),
(4, 'Svezia', 2),
(5, 'Polonia', 3),
(6, 'Repubblica Ceca', 3),
(7, 'Portogallo', 1),
(8, 'Francia', 2);

-- VENDITE
CREATE TABLE Vendite (
  Id_Vendita INT PRIMARY KEY,
  Id_Prodotto INT,
  Id_Stato INT,
  Data DATE,
  Quantità INT,
  Importo DECIMAL(10,2),
  FOREIGN KEY (Id_Prodotto) REFERENCES Prodotto(Id_Prodotto),
  FOREIGN KEY (Id_Stato) REFERENCES Stato(Id_Stato)
);

INSERT INTO Vendite VALUES
(1, 1, 1, '2025-01-01', 10, 70.00),
(2, 2, 3, '2025-02-15', 3, 430.00),
(3, 3, 5, '2025-03-10', 7, 30.00),
(4, 4, 7, '2025-04-22', 5, 35.00),
(5, 5, 2, '2025-05-01', 2, 1299.99),
(6, 6, 8, '2025-05-10', 4, 70.00),
(7, 7, 1, '2025-05-15', 6, 27.00);

-- ===================================================
-- TASK 4 – Punto 1: Verifica unicità delle chiavi primarie (PK)
-- ===================================================

-- Verifica PK nella tabella Categoria
SELECT Id_Categoria, COUNT(*) AS Conteggio
FROM Categoria
GROUP BY Id_Categoria
HAVING COUNT(*) > 1;

-- Verifica PK nella tabella Prodotto
SELECT Id_Prodotto, COUNT(*) AS Conteggio
FROM Prodotto
GROUP BY Id_Prodotto
HAVING COUNT(*) > 1;

-- Verifica PK nella tabella Regione
SELECT Id_Regione, COUNT(*) AS Conteggio
FROM Regione
GROUP BY Id_Regione
HAVING COUNT(*) > 1;

-- Verifica PK nella tabella Stato
SELECT Id_Stato, COUNT(*) AS Conteggio
FROM Stato
GROUP BY Id_Stato
HAVING COUNT(*) > 1;

-- Verifica PK nella tabella Vendite
SELECT Id_Vendita, COUNT(*) AS Conteggio
FROM Vendite
GROUP BY Id_Vendita
HAVING COUNT(*) > 1;

-- ===================================================
-- TASK 4 – Punto 2: Elenco transazioni con dettagli e controllo su 180 giorni
-- ===================================================

SELECT
  v.Id_Vendita AS Codice_Vendita,
  v.Data AS Data_Vendita,
  p.Nome_Prodotto,
  c.Nome_Categoria,
  s.Nome_Stato,
  r.Nome_Regione,
  CASE
    WHEN DATEDIFF(CURDATE(), v.Data) > 180 THEN TRUE
    ELSE FALSE
  END AS Oltre_180_Giorni
FROM Vendite v
JOIN Prodotto p ON v.Id_Prodotto = p.Id_Prodotto
JOIN Categoria c ON p.Id_Categoria = c.Id_Categoria
JOIN Stato s ON v.Id_Stato = s.Id_Stato
JOIN Regione r ON s.Id_Regione = r.Id_Regione;

-- ===================================================
-- TASK 4 – Punto 3:
-- Prodotti con quantità venduta maggiore della media dell’ultimo anno censito
-- ===================================================

SELECT
  v.Id_Prodotto,
  SUM(v.Quantità) AS Totale_Venduto
FROM Vendite v
WHERE YEAR(v.Data) = (
  SELECT MAX(YEAR(Data)) FROM Vendite
)
GROUP BY v.Id_Prodotto
HAVING SUM(v.Quantità) > (
  SELECT AVG(SommaTotale)
  FROM (
    SELECT SUM(Quantità) AS SommaTotale
    FROM Vendite
    WHERE YEAR(Data) = (
      SELECT MAX(YEAR(Data)) FROM Vendite
    )
    GROUP BY Id_Prodotto
  ) AS MediaVendite
);

-- ===================================================
-- TASK 4 – Punto 4:
-- Elenco dei soli prodotti venduti e fatturato totale per anno
-- ===================================================

SELECT
  p.Nome_Prodotto,
  YEAR(v.Data) AS Anno,
  SUM(v.Importo) AS Fatturato_Totale
FROM Vendite v
JOIN Prodotto p ON v.Id_Prodotto = p.Id_Prodotto
GROUP BY p.Nome_Prodotto, Anno
ORDER BY Anno, Fatturato_Totale DESC;

-- ===================================================
-- TASK 4 – Punto 5:
-- Fatturato totale per stato per anno
-- ===================================================

SELECT
  s.Nome_Stato,
  YEAR(v.Data) AS Anno,
  SUM(v.Importo) AS Fatturato_Totale
FROM Vendite v
JOIN Stato s ON v.Id_Stato = s.Id_Stato
GROUP BY s.Nome_Stato, Anno
ORDER BY Anno, Fatturato_Totale DESC;

-- ===================================================
-- TASK 4 – Punto 6:
-- Categoria più richiesta (quantità totale venduta)
-- ===================================================

SELECT
  c.Nome_Categoria,
  SUM(v.Quantità) AS Totale_Quantità
FROM Vendite v
JOIN Prodotto p ON v.Id_Prodotto = p.Id_Prodotto
JOIN Categoria c ON p.Id_Categoria = c.Id_Categoria
GROUP BY c.Nome_Categoria
ORDER BY Totale_Quantità DESC
LIMIT 1;

-- ===================================================
-- TASK 4 – Punto 7:
-- Prodotti invenduti – Approccio 1: LEFT JOIN
-- ===================================================

SELECT p.Id_Prodotto, p.Nome_Prodotto
FROM Prodotto p
LEFT JOIN Vendite v ON p.Id_Prodotto = v.Id_Prodotto
WHERE v.Id_Vendita IS NULL;

-- ===================================================
-- TASK 4 – Punto 7:
-- Prodotti invenduti – Approccio 2: NOT IN
-- ===================================================

SELECT Id_Prodotto, Nome_Prodotto
FROM Prodotto
WHERE Id_Prodotto NOT IN (
  SELECT DISTINCT Id_Prodotto FROM Vendite
);

-- ===================================================
-- TASK 4 – Punto 8:
-- Vista “denormalizzata” dei prodotti
-- ===================================================

CREATE VIEW Vista_Prodotti_Denormalizzata AS
SELECT
  p.Id_Prodotto,
  p.Nome_Prodotto,
  c.Nome_Categoria
FROM Prodotto p
JOIN Categoria c ON p.Id_Categoria = c.Id_Categoria;

-- ===================================================
-- TASK 4 – Punto 9:
-- Vista per le informazioni geografiche
-- ===================================================

CREATE VIEW Vista_Informazioni_Geografiche AS
SELECT
  s.Id_Stato,
  s.Nome_Stato,
  r.Nome_Regione
FROM Stato s
JOIN Regione r ON s.Id_Regione = r.Id_Regione;
